//
//  ViewWillShow.h
//  ContainerDemo
//
//  Created by qianfeng on 15/3/4.
//  Copyright (c) 2015年 WeiZhenLiu. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol ViewWillShow <NSObject>

- (void)viewWillShow;
@end
