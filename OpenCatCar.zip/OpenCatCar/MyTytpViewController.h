//
//  MyTytpViewController.h
//  OpenCatCar
//
//  Created by qianfeng on 15-6-18.
//  Copyright (c) 2015年 黄开. All rights reserved.
//

#import "TalkHotViewController.h"

@interface MyTytpViewController : TalkHotViewController

@end
