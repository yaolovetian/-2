//
//  Define_.h
//  OpenCatCar
//
//  Created by qianfeng on 15-6-10.
//  Copyright (c) 2015年 黄开. All rights reserved.
//

#ifndef OpenCatCar_Define__h
#define OpenCatCar_Define__h


#define kOpenCat @"opencat.png"
#define kZuiXin  @"http://a.xcar.com.cn/interface/6.0/getNewsList.php?limit=10&offset=%ld&type=1&ver=6.1.3&"

#define kXinWen  @"http://mi.xcar.com.cn/interface/xcarapp/getdingyue.php?limit=10&offset=%ld&type=1540&ver=6.1.3&"
#define kXinChe  @"http://mi.xcar.com.cn/interface/xcarapp/getdingyue.php?limit=10&offset=%ld&type=8&ver=6.1.3&"
#define kDuiBi  @"http://mi.xcar.com.cn/interface/xcarapp/getdingyue.php?limit=10&offset=%ld&type=76392&ver=6.1.3&"
#define kShangShi  @"http://mi.xcar.com.cn/interface/xcarapp/getdingyue.php?limit=10&offset=%ld&type=3&ver=6.1.3&"

#define kShiPin @"http://mi.xcar.com.cn/interface/xcarapp/getdingyue.php?limit=10&offset=%ld&type=144998&ver=6.1.3&"
#define kPingCe @"http://a.xcar.com.cn/interface/6.0/getNewsList.php?limit=10&offset=%ld&type=3&ver=6.1.3&"

#define kLuntan @"http://mi.xcar.com.cn/interface/xcarapp/getSelectedPostList.php?limit=20&offset=%ld&ver=6.1.3&"
#define kReTie @"http://my.xcar.com.cn/app/6/getHotPostList.php?limit=20&offset=%ld&ver=6.1.3&"

#define kJiangJia @"http://a.xcar.com.cn/interface/6.0/getEventList.php"
#define kLike @"http://a.xcar.com.cn/interface/6.0/eventIncrenment.php?eventId=%@&"
#define kFound @"http://mi.xcar.com.cn/interface/xcarapp/getRecommendedForumList.php"
#define kFoundURl @"http://mi.xcar.com.cn/interface/xcarapp/getPostListNew.php?uid=&limit=20&forumId=%@&sortType=1&ver=6.1.3&offset=%ld&type=0&selectId=0&"
#define kPersonCar @"http://mi.xcar.com.cn/interface/xcarapp/getForumList.php?type=2&ver=6.1.3&"
#define kLoveCar @"http://mi.xcar.com.cn/interface/xcarapp/getForumList.php?type=0&ver=6.0"

#define kZuiXinTytP   @"ZuiXin"
#define kLunTanTytp   @"LunTan"
#define kHotTytp      @"ReTie"
#define kFoundTytp    @"ZhaoLunTan"
#endif
