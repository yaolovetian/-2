//
//  JHRefreshHeaderView.h
//  JHRefresh
//
//  Created by Jiahai on 14-9-15.
//  Copyright (c) 2014年 Jiahai. All rights reserved.
//

#import "JHRefreshBaseView.h"

@interface JHRefreshHeaderView : JHRefreshBaseView

@end
