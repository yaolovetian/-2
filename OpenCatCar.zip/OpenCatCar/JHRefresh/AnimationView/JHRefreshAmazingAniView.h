//
//  JHRefreshAmazingAniView.h
//  JHRefresh
//
//  Created by Jiahai on 14-9-17.
//  Copyright (c) 2014年 Jiahai. All rights reserved.
//

#import "JHRefreshAniBaseView.h"

@interface JHRefreshAmazingAniView : JHRefreshAniBaseView
{
    UIImageView *_aniImgView;
}
@end
