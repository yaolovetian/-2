//
//  JHRefreshFooterView.h
//  JHRefresh
//
//  Created by Jiahai on 14-9-16.
//  Copyright (c) 2014年 Jiahai. All rights reserved.
//

#import "JHRefreshBaseView.h"

@interface JHRefreshFooterView : JHRefreshBaseView

@end
