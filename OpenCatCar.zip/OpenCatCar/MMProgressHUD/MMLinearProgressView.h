//
//  MMLinearProgressView.h
//  MMProgressHUD
//
//  Created by Jonas Gessner on 04.08.13.
//  Copyright (c) 2012 Jonas Gessner. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MMProgressView-Protocol.h"

@interface MMLinearProgressView : UIView <MMProgressView>

@end
