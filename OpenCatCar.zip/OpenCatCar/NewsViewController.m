//
//  newsViewController.m
//  OpenCatCar
//
//  Created by qianfeng on 15-6-10.
//  Copyright (c) 2015年 黄开. All rights reserved.
//

#import "NewsViewController.h"

@implementation NewsViewController
- (void)viewDidLoad {
    [super viewDidLoad];
     [self creatRefreshView];
    [self firstDownload];
    
}
@end
